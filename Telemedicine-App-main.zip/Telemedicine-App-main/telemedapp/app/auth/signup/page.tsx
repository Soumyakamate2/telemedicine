import SignUpForm from "@/components/auth/SignupForm";

function SignUpPage() {
  return <SignUpForm />;
}

export default SignUpPage;
