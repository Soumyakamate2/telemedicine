import ViewProfile from "@/components/doctorProfile/ViewProfile";

function ViewProfilePage() {
  return <ViewProfile />;
}

export default ViewProfilePage;
