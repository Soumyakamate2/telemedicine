import Chat from "@/components/doctorProfile/chat";

function ChatPage() {
  return <Chat />;
}

export default ChatPage;
