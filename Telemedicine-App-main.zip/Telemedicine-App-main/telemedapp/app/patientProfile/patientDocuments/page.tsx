import React from "react";
import PatientDocuments from "@/components/patientProfile/PatientDocuments";
const PatientDocumentsPage = () => {
  return <PatientDocuments />;
};

export default PatientDocumentsPage;
