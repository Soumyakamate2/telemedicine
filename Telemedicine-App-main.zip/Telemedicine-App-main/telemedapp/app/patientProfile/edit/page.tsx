import EditProfile from "@/components/patientProfile/EditProfile";

function EditProfilePage() {
  return <EditProfile />;
}

export default EditProfilePage;
